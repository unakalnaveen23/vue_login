// import connection
import db from "../restapi/db.js";
  
// Get All register
export const getnewregister = (result) => {
    db.query("SELECT * FROM allregister", (err, results) => {             
        if(err) {
            console.log(err);
            result(err, null);
        } else {
            result(null, results);
        }
    });   
}

// Insert new register to Database
export const putnewregister = (data, result) => {
    db.query("INSERT INTO allregister SET ?", [data], (err, results) => {             
        if(err) {
            console.log(err);
            result(err, null);
        } else {
            result(null, results);
        }
    });   
}

// Get All employee
export const getemployee = (result) => {
    db.query("SELECT * FROM myuser", (err, results) => {             
        if(err) {
            console.log(err);
            result(err, null);
        } else {
            result(null, results);
        }
    });   
}

// Get Single Product
export const getemployeeid = (id, result) => {
    db.query("SELECT * FROM myuser WHERE id = ?", [id], (err, results) => {             
        if(err) {
            console.log(err);
            result(err, null);
        } else {
            result(null, results[0]);
        }
    });   
}

// Insert employee to Database
export const insertemployee = (data, result) => {
    db.query("INSERT INTO myuser SET ?", [data], (err, results) => {             
        if(err) {
            console.log(err);
            result(err, null);
        } else {
            result(null, results);
        }
    });   
}
  
// Update employee to Database
export const updateemployee = (data, id, result) => {
    db.query("UPDATE myuser SET Emp_Name = ?, Emp_LastName = ?,Emp_email = ?,Emp_Desigination = ?,Emp_phoneno = ?,Emp_address = ? WHERE id = ?", [data.Emp_Name, data.Emp_LastName, data.Emp_email, data.Emp_Desigination, data.Emp_phoneno, data.Emp_address, id], (err, results) => {             
        if(err) {
            console.log(err);
            result(err, null);
        } else {
            result(null, results);
        }
    });   
}
  
// Delete employee to Database
export const deleteemployee = (id, result) => {
    db.query("DELETE FROM myuser WHERE id = ?", [id], (err, results) => {             
        if(err) {
            console.log(err);
            result(err, null);
        } else {
            result(null, results);
        }
    });   
}