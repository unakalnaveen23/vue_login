// Import function from Product Model
import {getnewregister, putnewregister, getemployee, getemployeeid, insertemployee, updateemployee, deleteemployee } from "../restapi/employeemodule.js";
import con from "./db.js";
  
// get all registeration
export const getnewresgiteration = (req, res) => {
    getnewregister((err, results) => {
        if(err){
            res.send(err);
        }else{
            res.json(results);
        }
    })
}

// put new registeration
export const putnewresgiteration = (req, res) => {
    const data = req.body;
    putnewregister(data,(err, results) => {
        if(err){
            res.send(err);
        }else{
            res.json(results);
        }
    })
}

// Get All employee
export const showemployee = (req, res) => {
    getemployee((err, results) => {
        if (err){
            res.send(err);
        }else{
            res.json(results);
        }
    });
}

// Get Single employee 
export const showemployeebyid = (req, res) => {
    getemployeeid(req.params.id, (err, results) => {
        if (err){
            res.send(err);
        }else{
            res.json(results);
        }
    });
}

// Create New employee
export const createemployee = (req, res) => {
    const data = req.body;
    insertemployee(data, (err, results) => {
        if (err){
            res.send(err);
        }else{
            res.json(results);
        }
    });
}
  
// Update employee
 export const updateemployeebyid = function(req, res){
    const data  = req.body;
    const id    = req.params.id;
    updateemployee(data, id, (err, results) => {
        if (err){
            res.send(err);
        }else{
            res.json(results);
        }
    });
}
  
// Delete employee

export const deleteemployeebyid = (req, res) => {
    const id = req.params.id;
    deleteemployee(id, (err, results) => {
        if (err){
            res.send(err);
        }else{
            res.json(results);
        }
    });
}