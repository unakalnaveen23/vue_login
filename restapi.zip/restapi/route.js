// import express
import express from "express";
  
// import function from controller
import {getnewresgiteration, putnewresgiteration, showemployee, showemployeebyid, createemployee, updateemployeebyid, deleteemployeebyid } from "../restapi/employee.js";
  
// init express router
const router = express.Router();

//get all register detials
router.get('/newregister', getnewresgiteration)

//put new register detials
router.post('/newregister', putnewresgiteration)
  
// Get All employee
router.get('/employee', showemployee);

// get employee
router.get('/employee/:id', showemployeebyid);
   
// Create New employee
router.post('/employee', createemployee);

// Update employee
router.put('/employee/:id', updateemployeebyid);
  
// Delete employee
router.delete('/employee/:id', deleteemployeebyid);
  
// export default router
export default router;